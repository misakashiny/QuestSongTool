# Quest歌单对比工具 v17.8

对比 PC 本地与 Meta Quest 头显上的 Beat Saber 自定义歌曲：评分/评价、搜索排序、
一键补齐缺失歌曲、设备端删除。

> **刚接手这个项目？先读 [`HANDOVER.md`](HANDOVER.md)** —— 那里有一分钟摘要、
> 环境自检步骤、架构说明、已知坑与迭代清单。
> 用户报"选不了文件夹/老弹窗" → [`docs/06_Quest3连接与文件夹选择.md`](docs/06_Quest3连接与文件夹选择.md)

---

## 快速开始

```powershell
pip install customtkinter pillow

python main.py                  # 启动图形界面
python -m quest_tool --doctor   # 环境自检（依赖 / 目录 / adb / 便携设备）
python -m quest_tool --scan     # 只探测 Quest 位置并打印结果
python tests\run_all.py         # 跑全部 19 组自动化测试
```

**三步用法**：① 分别载入本地与 Quest 的 `CustomLevels` 文件夹 →
② 点「🔍 Quest 缺的」对比 →③ 点「📤 缺失 → Quest」补齐。

**Quest 连接方式**（详见用户文档）：

| 方式 | 需要什么 | 适用 |
|---|---|---|
| **adb**（推荐） | 装 Android Platform Tools，头显开开发者模式并允许 USB 调试 | 读写/删除，速度快 |
| **MTP**（免安装） | 插上即可 | 程序自动把设备歌曲镜像到本地再解析，较慢，不删设备文件 |

> 系统自带的「选择文件夹」对话框**无法选中 MTP 设备里的目录**（Windows 没给 MTP 设备盘符），
> 这是系统限制，所以程序内置了自己的设备文件夹选择器。

---

## 界面预览

| 列表视图（深色） | 封面墙视图 |
|---|---|
| ![列表视图](docs/images/01-主界面-深色.png) | ![封面墙](docs/images/03-封面墙视图.png) |

| 列表视图（浅色） | 确认对话框 |
|---|---|
| ![浅色](docs/images/02-主界面-浅色.png) | ![对话框](docs/images/04-确认对话框.png) |

---

## 数据文件位置

都写在**程序所在目录**（打包后是可执行文件目录；不可写时自动退回 `%LOCALAPPDATA%\QuestSongComparator`）：

| 文件 | 用途 |
|---|---|
| `settings.json` | 路径、主题、adb 路径、列宽、视图模式（损坏时自动备份为 `.bak` 并回落默认值） |
| `songs_cache.db` | 歌曲元数据缓存 + 评分/评价（评分按「位置 + 文件夹名」存储，本地与设备互不影响） |
| `logs/quest_comparator.log` | 运行日志（2 MB 轮转，保留 3 份） |

---

## 模块结构

```
main.py                        启动入口
quest_tool/
├─ app.py                      主窗口 + 业务编排
├─ theme.py                    设计令牌（语义色板浅/深 + 间距/圆角/字号）
├─ constants.py                常量、字体、Quest 路径候选
├─ storage.py                  运行目录、settings.json（原子写、损坏自愈）
├─ logging_setup.py            日志（懒初始化 + 轮转）
├─ database.py                 SQLite：meta（元数据）+ userdata（评分/评价）
├─ songs.py                    info.dat 解析（v1~v4、多编码兜底）
├─ fsapi.py                    文件系统抽象（SongFS / LocalFS）
├─ adb.py                      adb 桥（查找、设备、ls/cat/pull/push、tar 批量读）
├─ device_adb.py               adb 后端（批量元数据、删除护栏）
├─ device_mtp.py               MTP 后端（Shell CopyHere 镜像）
├─ device_shell.py             Shell 命名空间桥（PowerShell 枚举便携设备）
├─ device.py                   设备探测：盘符 → adb → MTP
├─ workers.py                  后台任务 + 消息队列 + 危险操作护栏
├─ ui_songlist.py              歌曲列表（分页/搜索/多选/列宽/悬停）
├─ ui_coverwall.py             封面墙（虚拟化网格 + 异步封面）
├─ ui_dialogs.py               统一对话框（ModalDialog + 6 个子类）
├─ ui_devicepicker.py          设备文件夹浏览器
├─ ui_dnd.py                   拖拽导入（WM_DROPFILES，零依赖）
├─ ui_toast.py                 右下角通知
└─ shell_probe.ps1 / shell_copy.ps1   PowerShell 辅助脚本（UTF-8 BOM）
```

---

## 主要特性

### 数据安全（原版有实测事故，均已修复）

| 原版行为 | 新版行为 |
|---|---|
| 两个路径框填成同一目录时，复制会**先删源歌曲再复制**（实测源目录被清空） | `guard_copy()` 在动手前拦截"源==目标 / 互为父子目录" |
| 删除走 `shutil.rmtree(base_path)`，路径变量为空时会删**当前工作目录下的相对路径** | `guard_delete()` 强制绝对路径 + 必须是根目录的直接子目录 + 拒绝盘符根 |
| 删除在主线程执行，大目录卡死界面 | 后台执行，并**删除后复查**目录是否真的消失 |
| MTP 覆盖已存在歌曲时弹「替换/跳过」对话框等人点，或静默跳过导致歌曲没更新 | 标志位 1556（不弹窗）+ 复制前把旧文件夹改名挪开（保证真的更新） |

### 功能

拖拽导入 ｜ 多选批量删除 ｜ **跨页多选**（`Ctrl+A` 当前页 / `Ctrl+Shift+A` 全部页）｜
封面墙视图 + 右键菜单 ｜ **三列筛选档位（全部 / 已匹配 / 缺失）** ｜ 复制前显示总大小/预计耗时 ｜ 增量扫描（只解析新歌与改动过的）｜
列宽可拖拽并记忆 ｜ 行悬停高亮 ｜ 圆角+阴影封面 ｜ Toast 非模态通知 ｜
菜单栏 + 快捷键 ｜ 深浅主题切换 ｜ **可拖动分栏** ｜ **高 DPI 适配** ｜ **中英双语** ｜
**首次使用向导** ｜ **无线调试连接** ｜ **重复歌曲检测** ｜ **对比报告导出（CSV / Markdown）** ｜
**Beat Saber 歌单导入导出（`.bplist`）** ｜ **试听片段** ｜ 可打包成 exe

### 三列的区分方式（v17.4）

本地 / Quest / 缺失三列各有一套**图标 + 语义色**（`app_common.COLUMN_IDENTITIES` 一处定义）：

| 列 | 图标 | 色 | 含义 |
|---|---|---|---|
| 本地歌曲 | 💻 | 蓝 `ACCENT` | 只读、主操作 |
| Quest 歌曲 | 🥽 | 紫 `INFO` | 设备侧 |
| 缺失歌曲 | ⚠️ | 橙 `WARNING` | 待处理 |

**图标和颜色是双重编码**：色盲用户靠图标也能分列。列表标题栏、封面墙标题栏、
空状态提示三处都会带上本列图标，所以"这块空白属于哪一列"永远看得出来。

底部操作按钮按**副作用**分成四组四色，不是随便挑的好看颜色：

| 组 | 色 | 说明 |
|---|---|---|
| ① 载入 | 蓝 | 只读，不改任何数据 |
| ② 对比 | 紫 | 只改"缺什么"这一视图 |
| ③ 补齐 | 绿 | **真的往磁盘/设备写文件** |
| ④ 删除 | 红 | **不可逆** |

扫一眼颜色就知道哪颗按钮会动文件。

### 三列的筛选档位（v17.7）

每列除了搜索框，还有三个**档位**按钮，旁边带实时数量：

| 档位 | 本地列的含义 | Quest 列的含义 |
|---|---|---|
| **全部** | 本地曲库所有歌 | Quest 上所有歌 |
| **已匹配** | 这首歌 Quest 上也有 | 这首歌本地也有 |
| **缺失** | Quest 上没有 | 本地没有 |

「已匹配 / 缺失」都是**相对另一侧**说的，数量在每次灌数据时刷新，
所以**还没点「对比」也能先看到有几百首对不上**。

用法举例：本地列切到「缺失」→ 再按 `Ctrl+Shift+A` 全选 → 点「📤 → Quest」，
就是「把 Quest 上缺的全补过去」。

**界面语言**：设置里可切中/英（`quest_tool/messages.py`，235 条文案）。
**全部界面文案都走文案表** —— 注释、日志、异常消息仍为中文，那是给开发者看的，不是界面。
CI 级的检查（`tests/smoke_i18n.py`）会挡住"又写回内联中文"，英文界面实测零中文残留。

### 试听片段

详情栏的 **▶ 试听** 按钮播放当前歌曲的片段，进度条可**拖动**跳转（拖动时暂停跟随，松手才跳）。

**时长可配**：设置对话框里可选 **15 秒 / 30 秒 / 60 秒 / 整曲**，默认 30 秒。
（原先固定 30 秒是**人为设的上限**，不是格式或设备限制 —— 试听只为快速认歌。）

**拖动是"从这一秒重新起播"**，不是设备级快进：miniaudio 那条生成器链路没有随机访问能力，
所以每次跳转都会重新开一段解码。

**只支持本地歌曲**：设备上的歌要先拉 4~13 MB 音频下来才能放，那是"为听 5 秒传一个文件"，
不如先复制到本地。界面会明说这条原因，而不是静默失败。

**依赖是软性的**：`miniaudio` 只在本功能被调用时才 import。没装不影响程序启动，
只是按钮变灰并给出提示（`pip install miniaudio`）。

**解码是流式的**：`song.egg` 内容就是 OGG，但**扩展名**不被 miniaudio 认
（`stream_file(路径)` 会按扩展名猜格式 → `DecodeError: unsupported file format`），
所以读成字节再走 `stream_memory(字节)`。

**停止不卡界面**：`device.stop()` 内部要 join 音频回调线程，实测耗时≈
`buffersize_msec` 的 2.5 倍（200ms → 约 600ms）。它原本是在**界面线程**上同步调的 ——
停止、切歌、拖动起点全都会卡半秒。现在关停丢给后台线程，实测 **600 ms → 0.5 ms**。

实测（13.66 MB / 369 秒的文件，`tracemalloc` 峰值）：

| 做法 | 耗时 | 峰值内存 |
|---|---|---|
| 整曲解码再切片（v16.8 的实现） | 580 ms | 66.0 MB |
| `stream_preview()`（现在） | **72 ms** | **13.7 MB** |

13.7 MB 就是源文件缓冲本身，解码增量接近零。详见 `quest_tool/audio.py` 的
`stream_preview()` 文档串（含三个必须注意的实现细节）。

### Beat Saber 歌单（`.bplist`）

菜单「文件 → 导出 Beat Saber 歌单」/「导入 Beat Saber 歌单并高亮匹配」。

**这个格式的关键：游戏按 `hash` 找歌，不是按名字。** `hash` 是谱面文件的 SHA-1
（`info.dat` 的内容 + 它按顺序列出的每个难度文件，依次拼接后取 SHA-1）。
hash 不对的话，歌单在游戏里**能打开却一首都不显示**。

所以导出时是真算 hash 的：

* **算不出 hash 的歌照样写进去，但会明确告诉你"这几首在游戏里不会显示"** ——
  不静默丢弃，也不用名字伪造一个 hash（错的 hash 会让歌单看起来正常、实际空白）；
* `info.dat` 或某个难度文件缺失/损坏 → 判为"算不出"，而不是给一个猜的值；
* 导出要读每首歌的 `info.dat` 和全部难度文件，几百首有明显耗时 → 后台执行 + 进度窗口。

导入**不做复制**：它只告诉你"这份歌单里你有哪些"，在列表里高亮出来；
要补齐没有的，接着用「复制缺失」即可。匹配**优先按 hash**；hash 对不上时才退回
"标题 + 谱师**都**相同"（**不做只按标题的匹配** —— 重名歌太多，会把歌单对到错误的歌上）。

> ⚠️ **导出后请上机确认**：把 `.bplist` 放进 Quest 的 `Playlists` 目录，
> 在游戏里确认歌单真的显示出这些歌。算法已与独立计算的 SHA-1 逐位对照过，
> 但"游戏认这个文件"只能上机验证。

### 正确性（原版缺陷 → 修复）

UTF-8 BOM / GBK 的 `info.dat` 不再解析失败 ｜ 缓存按 mtime 真正生效 ｜
无 `info.dat` 的歌曲评分不再丢失 ｜ 本地与 Quest 同名歌曲评分不再串号 ｜
高亮用文件夹名而不是下标（排序后不再高亮错歌）｜ 搜索框里按 Delete 不再触删除 ｜
难度解析覆盖 v1~v4 ｜ 解析时长与封面文件名

### "看起来成功、实际没生效"这类缺陷（本项目最高发，共 10 次）

值得单独列出来，因为**它们都不报错、界面看着正常**：

| 缺陷 | 症状 | 为什么没被发现 |
|---|---|---|
| `tar` 分组调用 | 217 首变 217 次调用（18.2 秒） | 结果是对的，只是慢 |
| 回退 `find` 命令 | 真机上永远返回 0 行 | `find /sdcard` 在符号链接上不工作 |
| toybox `find -printf '%y'` | 输出被截断成 1 行 | 本机 fake adb "太正确"，掩盖了真机行为 |
| 增量扫描 | 缓存永远命中 0，每次全量重解析 | 功能没报错，只是从没生效 |
| `prune_meta` | `keep_names` 语义反了（`IN` 应为 `NOT IN`） | 该函数从未被调用 |
| `shell_copy.ps1` | 复制 1 首会推送**整个歌库** | 3 首的测试里"3 首全成功"看着像正常 |
| `self._missing_side` | 封面墙「缺失」列永远空白 | 读的是从未赋值的属性，`AttributeError` 被 `except` 吞掉 |
| 缺失列表删除 | 按 Delete 什么都不做 | `delete_missing_song` 无人调用，且方向是反的 |
| 预计耗时 | 按**源**侧速率算（150 MB/s），实际 17.4 MB/s | 数字看着合理 |
| 歌单 hash | 猜一个 hash → 歌单打开但一首不显示 | 文件本身完全合法 |

**共同教训**：功能"写好了"和"生效了"是两件事。
所以仓库里有两道网 —— `tests/static_check.py`（未定义名 / 未使用 import / 后台线程碰 UI /
Settings 字段没人读 / `.ps1` 的 BOM）和 `HANDOVER.md` 第 19 条要求的**周期性死代码体检**。

### 性能（实测）

| 场景 | 原版 | 新版 |
|---|---|---|
| 渲染 2000 首 | 8001 个 Tk 控件 / 15.5 秒 | 只渲染当前页，控件总数恒定 51 |
| 搜索连敲 5 个字符（1000 首） | 29.8 秒（界面假死） | 180 ms 防抖 + 只重排当前页 |
| 载入 Quest 歌单（真机 217 首） | 不可用 | **冷启动 1.47 秒 / 第二次 0.88 秒（缓存全命中）** |
| 取 217 首的 mtime | — | **一次 `find` 0.35 秒**（逐首 stat 要 17.6 秒） |
| 读上千个 `info.dat` | 不可用 | `tar` 单流批量读：217 首 0.74 秒 |
| 封面墙首屏 | — | 852 ms（虚拟化 + 每格 3 个控件） |

> 上面几项都在真机 Quest 3 上量过。**注意"增量扫描"直到 v14.5 才真正生效** ——
> 此前载入时从不把元数据落库，缓存永远命中 0，每次都是全量重解析（见 `CHANGELOG.md` v14.5）。

### 线程安全

**工作线程只允许 `queue.put()`**；`TaskRunner` + `app._pump_queue()` 是唯一 UI 更新入口；
任务带 token，旧任务的迟到消息会被丢弃。（原版有 11 处工作线程直接碰 Tk）

---

## 测试与验证

```powershell
python tests\run_all.py            # 一键跑全部 19 组（推荐）
python tests\static_check.py       # 静态：未定义名 / PowerShell 脚本 BOM / 未用 import / 后台碰 UI / Settings 字段（秒级，先跑这个）
python tests\e2e_core.py           # 扫描/解析/缓存/对比/护栏/真实复制删除
python tests\e2e_adb.py            # 假 adb 驱动完整读写删
python tests\e2e_mtp.py            # MTP 镜像 + 解析
python tests\e2e_gui.py            # 真实窗口驱动整条主流程
python tests\smoke_features.py     # 多选/列宽/悬停/封面墙/拖放/设置往返
python tests\smoke_songlist.py     # 列表/分页/跨页多选/排序/快捷键
python tests\smoke_dialogs.py      # 各对话框
python tests\smoke_i18n.py         # 文案表一致性 + 切换生效 + 不许退回内联中文
python tests\smoke_wireless.py     # 无线调试（假 adb 回放，含全部失败路径）
python tests\smoke_duplicates.py   # 重复检测（一半在测"不该报的绝不能报"）
python tests\smoke_diagnostics.py  # 卡死诊断：慢操作记录 / 看门狗 / 异常接管 / 日志尾部
python tests\smoke_audio.py        # 试听：真音频解码 / 流式限长（会开真声卡，有声音）
python tests\selftest_playlist.py  # 歌单导入导出（.bplist）
python tests\scaling_check.py      # 高 DPI 三档：不裁切、不重叠
python tests\screenshot_regression.py  # 与基线像素比对（配色/版式改坏会失败）
python tests\screenshot.py         # 无人值守出图（UI 回归）
python tests\diag_layout3.py       # 打印各区域几何，定位布局问题
python tests\diag_boxes.py         # 洪水填充定位截图上画错的控件
```

**真机写/删验证**（会改设备数据，所以**不**在 `run_all.py` 里，且默认只演练）：

```powershell
python tests\e2e_device_real.py         # 演练：只打印计划，不动设备
python tests\e2e_device_real.py --yes   # 真跑：新建测试歌曲 → 校验 → 删除 → 比对歌单
```

`tests/archive/` 里保留了重构过程中的一次性排查与取证脚本（用途见该目录 README）。

---

## 卡住了怎么办（v17.6）

程序会**自己记录卡顿**。如果用户觉得"点了没反应""卡死"：

1. 菜单 **「帮助 → 环境自检信息」** —— 一屏就能看到版本/缩放/曲库数量、
   看门狗状态与**当前正在跑的操作**，以及**最近的警告与错误**，可一键复制。
2. 日志文件：`logs/quest_comparator.log`（菜单「文件 → 打开日志目录」）。
   日志会写明「慢操作：建立主界面 用了 1302 ms（线程=MainThread，界面线程=是）」
   以及「界面线程卡顿 1.5 秒，多半卡在刚跑完的『建立主界面』上」。

**记录里为什么一定要有「界面线程=是/否」**：同样耗时 1 秒，跑在界面线程上才叫
卡死，跑在后台线程上只是慢。不区分的话，看日志的人会去优化一条不影响体验的路径。

三个参数在 `quest_tool/diagnostics.py`：`TICK_SECONDS = 0.05`（心跳）、
`STALL_FACTOR = 5.0`（卡顿判据 = 0.25 秒）、`SLOW_SECONDS = 0.8`（慢操作）。

## 打包成 exe（免装 Python）

```powershell
pip install pyinstaller
pyinstaller quest_tool.spec --noconfirm
```

产物在 `dist\QuestSongCompare\`（onedir，约 37 MB），双击里面的
`QuestSongCompare.exe` 即可。**整包一起拷走**，别只拷 exe。

调试时想看控制台输出（`--doctor` / `--scan`）：

```powershell
$env:QUEST_CONSOLE="1"; pyinstaller quest_tool.spec --noconfirm
```

配置/日志/数据库都在 exe 同级目录；如果那个目录不可写（例如装在 `Program Files`），
会自动回退到 `%LOCALAPPDATA%\Quest歌单对比工具\`。

> `quest_tool.spec` 里踩过的两个坑写在文件注释里，改打包配置前先读：
> **customtkinter 的主题 JSON 要 `collect_data_files`**、
> **两个 `.ps1` 必须 `datas` 打进去**（运行时按路径读取，不是 import）、
> **别把 `setuptools` 排除掉**（`pkg_resources` 的运行时钩子需要它）。

---

## 从原版迁移评分/评价

原版（单文件版）把评分混在 `songs` 表里、只按 `folder_name` 唯一；新版拆到了 `userdata`，
键是 `(location, folder_name)`。所以升级过来要迁一次：

```powershell
python -m quest_tool --migrate-legacy "D:\旧版\songs_cache.db" --location "local:D:\Songs"
```

* `--location` 必填：告诉它这些歌属于哪个位置（`local:D:\Songs`、
  `adb:/sdcard/ModData/com.beatgames.beatsaber/Mods/SongCore/CustomLevels` 等）；
* **只读打开旧库**，绝不动它；**幂等**，重复执行不会产生重复行、也不会覆盖新版里改过的分；
* 只迁有评分或评价的记录（原版表里全是歌，绝大多数没评分）。

---

## 文档索引

| 文档 | 给谁看 |
|---|---|
| [`HANDOVER.md`](HANDOVER.md) | **接手开发的人**：环境、架构、坑、迭代清单 |
| [`docs/06_Quest3连接与文件夹选择.md`](docs/06_Quest3连接与文件夹选择.md) | 用户/客服：连不上设备、选不了文件夹、弹窗问题 |
| [`docs/02_UI设计说明.md`](docs/02_UI设计说明.md) | 改界面的人：设计令牌、版式、UI 待办 |
| [`docs/01_代码审查-原版问题清单.md`](docs/01_代码审查-原版问题清单.md) | 想知道"为什么重构"的人：原版逐行审查 |
| [`docs/05_改进记录-重构前后对照.md`](docs/05_改进记录-重构前后对照.md) | 同上：15 项缺陷的修复对照与实测数据 |
| [`CHANGELOG.md`](CHANGELOG.md) | 版本变更记录 |
| [`docs/reference/`](docs/reference/) | 原版单文件代码、另一套 MTP 参考实现 |

---

## 已知限制

* **adb 通道已完整实测**：Quest 3 / Android 14 / 216 首真实歌单 —— `--scan`、
  载入（冷 1.47 秒 / 第二次 0.88 秒）、封面 216/216、复制到设备（含中文歌名）、
  设备端删除与护栏，全部通过，跑完歌单复原。
* **MTP 通道未在真机上实测**：本机 Quest 的 MTP 没枚举出来（`VID_2833` 的
  `XRSP`/`COMMLIB`/`Highwind` 三个 Meta 私有接口缺驱动报 Error，`ADB Interface` 正常）。
  MTP 的逻辑靠 `tests/e2e_mtp.py` 验证 —— 它用的是**真实 PowerShell + COM `CopyHere`**，
  只是把设备换成一个本地目录，所以命令语义是测到了的。
* **MTP 模式较慢**且不删除设备文件；首次加载会把歌曲目录镜像到本地
  （之后是**增量**更新：只拉新增/改动过的）。
* **MTP 无法保留文件时间戳**（Android 协议限制），该模式下增量扫描会自动退回全量。
* MTP 的复制后校验只能比**文件数**（Shell 的"大小"列是四舍五入后的字符串，比不了字节）。
* **评分/评价是按"位置标识"存的**（`local:D:\Songs` / `adb:/sdcard/...`），
  所以从 MTP 换成 adb（或换了挂载方式）后，**旧位置下的评分看起来会"消失"**。
  数据没丢（在 `songs_cache.db` 的 `userdata` 表里，键是位置标识），
  但目前没有自动迁移 —— 安全的迁移需要判断"两个位置是不是同一个曲库"。
* 设备到设备的复制会先经本地临时目录中转。
