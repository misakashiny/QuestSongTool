' ============================================================
'  Quest Song Compare - launcher (no console window)
'
'  1. .vbs runs under wscript.exe, so no black console window.
'  2. Errors are shown with MsgBox, because a double-click gives
'     the user no stdout to read.
'  3. The messages are deliberately ASCII-only: this file is read
'     as ANSI by cscript/wscript, so Chinese text turns to mojibake
'     unless the file is written in the local codepage.
'
'  Difference from QiDong.bat:
'    QiDong.bat -> shows pip progress and errors (use it first)
'    QiDong.vbs -> fully windowless, good for a desktop shortcut
' ============================================================

Option Explicit

Dim fso, shell, here, mainPy, interpreter, i, exec, line
Dim candidates

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

' Folder this script lives in (the repo root when double-clicked)
here = fso.GetParentFolderName(WScript.ScriptFullName)
mainPy = fso.BuildPath(here, "main.py")

If Not fso.FileExists(mainPy) Then
    MsgBox "main.py not found:" & vbCrLf & mainPy & vbCrLf & vbCrLf & _
           "Please put this launcher inside the program folder.", _
           16, "Quest Song Compare"
    WScript.Quit 1
End If

interpreter = ""

' Try pythonw.exe first (no console), then python.exe.
' `where` searches PATH, which is more reliable than guessing install dirs.
Set exec = shell.Exec("cmd /c where pythonw.exe 2>nul")
If Not exec.StdOut.AtEndOfStream Then
    line = Trim(exec.StdOut.ReadLine())
    If fso.FileExists(line) Then interpreter = line
End If

If interpreter = "" Then
    Set exec = shell.Exec("cmd /c where python.exe 2>nul")
    If Not exec.StdOut.AtEndOfStream Then
        line = Trim(exec.StdOut.ReadLine())
        If fso.FileExists(line) Then interpreter = line
    End If
End If

If interpreter = "" Then
    MsgBox "Python was not found on this computer." & vbCrLf & vbCrLf & _
           "Install Python 3.10 or newer and tick 'Add Python to PATH':" & vbCrLf & _
           "    https://www.python.org/downloads/" & vbCrLf & vbCrLf & _
           "Or use QiDong.bat in the same folder for a detailed message.", _
           16, "Quest Song Compare"
    WScript.Quit 1
End If

' 0 = hidden window, False = do not wait (the GUI keeps running on its own)
' WorkingDirectory matters: the app resolves settings.json relative to cwd
' on first run.
shell.CurrentDirectory = here
shell.Run """" & interpreter & """ """ & mainPy & """", 0, False
