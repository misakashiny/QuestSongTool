' ============================================================
'  Create a desktop shortcut for Quest Song Compare
'
'  Double-click this file. It creates a shortcut on the desktop,
'  so from then on you can just click the desktop icon instead of
'  coming back to this folder.
'
'  Running it again is safe: the old shortcut is overwritten.
'
'  Messages are ASCII-only on purpose: cscript/wscript read .vbs
'  in the local ANSI codepage, so Chinese text would be mojibake.
' ============================================================

Option Explicit

Dim fso, shell, here, target, linkPath, link

Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

here = fso.GetParentFolderName(WScript.ScriptFullName)

' Prefer the windowless launchers; fall back to the .bat
Dim qidongVbs, qidongPyw, qidongBat
qidongVbs = fso.BuildPath(here, ChrW(21551) & ChrW(21160) & ".vbs")
qidongPyw = fso.BuildPath(here, ChrW(21551) & ChrW(21160) & ".pyw")
qidongBat = fso.BuildPath(here, ChrW(21551) & ChrW(21160) & ".bat")

target = ""
If fso.FileExists(qidongVbs) Then
    target = qidongVbs
ElseIf fso.FileExists(qidongPyw) Then
    target = qidongPyw
ElseIf fso.FileExists(qidongBat) Then
    target = qidongBat
Else
    MsgBox "No launcher found in:" & vbCrLf & here & vbCrLf & vbCrLf & _
           "Expected QiDong.vbs / QiDong.pyw / QiDong.bat.", _
           16, "Quest Song Compare"
    WScript.Quit 1
End If

linkPath = shell.SpecialFolders("Desktop") & "\Quest Song Compare.lnk"

Set link = shell.CreateShortcut(linkPath)
link.TargetPath = target
link.WorkingDirectory = here
link.Description = "Compare Beat Saber song lists between PC and Meta Quest"
link.IconLocation = "shell32.dll,138"
link.Save

MsgBox "Desktop shortcut created:" & vbCrLf & linkPath & vbCrLf & vbCrLf & _
       "From now on just double-click it on the desktop.", _
       64, "Quest Song Compare"
