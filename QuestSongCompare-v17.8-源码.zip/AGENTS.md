# AGENTS.md —— AI 开发入口（先读这一页）

> 这是一个 **Windows 桌面 GUI 工具**：对比 PC 本地与 Meta Quest 头显上的 Beat Saber 自定义歌曲。
> 本文件是给 AI 开发者的**最短入口**。深入内容一律去 `docs/00_AI接手指南.md`。

---

## 0. 三条铁律（违反会直接把项目搞坏）

1. **不许在文档里写没验证过的结论。** 凡是"已完成 / 已修复 / 实测通过"，必须有命令输出或数字支撑。
   本项目最高发的缺陷类型就是**「写了但没生效」**（累计 12 次：注释说流式其实没流式、文档说增量其实全量、
   函数写好了没人调用）。**文档会替错误打掩护** —— 所以每个"就这样实现的"都要能被测试或度量证实。
2. **改完代码立刻跑静态检查**：`python tests\static_check.py`（7 项，秒级）。
   它会抓未定义名、未使用 import、后台线程碰 UI、Settings 字段没人读、调用不存在的方法、
   `getattr` 永远取不到、`.ps1` 的 UTF-8 BOM 丢失。
3. **功能不许丢**。这个工具会给用户**真的删设备上的文件**。任何改动都要先回答：
   "这会不会让它删错东西？" 宁可多一次确认，不可少一次护栏。

---

## 1. 环境与命令（照抄即可）

```powershell
# 仓库根目录
cd "D:\AI Dsh\Quest3项目\beatsaber歌曲转移"

# 依赖（customtkinter / Pillow 必需；miniaudio 是试听的软依赖）
python -m pip install customtkinter Pillow miniaudio

# 启动 GUI
python main.py

# 环境自检（版本，tkinter/PIL/customtkinter，adb，Shell 采集器，界面偏好）
python -m quest_tool --doctor

# 一键跑全部测试（19 组，最后一个会弹真实窗口并置顶）
python tests\run_all.py

# 只跑指定几组
python tests\run_all.py static core adb

# 静态检查（7 项，零依赖，秒级）—— 改完代码先跑这个
python tests\static_check.py

# 打包 exe（可选，onedir 约 37 MB）
pyinstaller quest_tool.spec --noconfirm
```

**本机已验证的工具路径**（不在 PATH 里，脚本内已用常量处理）：

| 工具 | 路径 |
|---|---|
| Python 3.13 | `C:\Users\Administrator\AppData\Local\Programs\Python\Python313\python.exe` |
| Git | `C:\Program Files\Git\cmd\git.exe` |
| adb | `C:\Android\Sdk\platform-tools\adb.exe` |

---

## 2. 代码地图（只列最关键的）

```
main.py            启动入口
quest_tool\        ★ 全部产品代码，31 个模块，约 11800 行
  app.py             界面骨架（2440 行 → 现已拆出 5 个 mixin）
  app_*.py           5 个 mixin：copy / delete / device / detail / report
  app_common.py      mixin 共用的纯函数与常量（★ 加新共用件放这里）
  ui_*.py            控件与对话框（列表 / 封面墙 / 对话框 / 设备选择器 / 拖放 / 提示 / 向导 / 无线）
  workers.py         ★ 后台任务队列 + 消息泵 + 危险操作护栏（线程规约的落点）
  fsapi.py           ★ 文件系统抽象层：SongFS 接口 + LocalFS + verify_copy
  device*.py         设备后端：adb / MTP / 盘符 三选一
  theme.py           ★ 设计令牌（配色、间距、圆角、字体、DPI 缩放）
  messages.py        ★ 中英文案表 + tr()（**所有用户可见文字都走这里**）
  audio.py           试听（惰性导入 miniaudio）
  diagnostics.py     ★ 主线程卡顿看门狗 + slow() 埋点
tests\             19 组测试（run_all.py 是入口）+ 排查工具 + 假 adb
docs\              文档（索引见 docs\README.md）
```

架构分层、线程规约、以及「改代码前必读」的 4 条设计约束，见 `docs/00_AI接手指南.md` 第 4 节。

---

## 3. 改代码的固定动作

| 你要改什么 | 必须同时做的事 |
|---|---|
| 任何 `.py` | 跑 `python tests\static_check.py` |
| 界面文字 | 加进 `messages.py` 中英**两份**；跑 `smoke_i18n` |
| 配色 / 间距 | 只改 `theme.py`；跑 `theme_contrast.py`（WCAG 对比度会拦住"太白"） |
| 界面版式 | 跑 `scaling_check.py`（它会拦住"控件被挤扁"这类无声坏法） |
| 后台线程 | 只允许 `tasks.emit(...)`，**绝不碰 Tk 控件、绝不 `root.after()`** |
| 复制 / 删除 | 跑 `e2e_core.py` + `e2e_adb.py`；**不许绕过 `workers.py` 里的护栏** |
| `shell_*.ps1` | **必须保存为 UTF-8 with BOM**（编辑工具会静默去掉 BOM，静态检查第 2 项守着） |
| 任何改动 | 跑 `python tests\run_all.py`，必须 **19/19 组通过** |
| 任何改动 | 同步更新 `CHANGELOG.md` + 相关文档（见第 5 节） |

---

## 4. 测试与验证

```powershell
python tests\run_all.py        # 19 组全跑（必须 19/19）
python tests\static_check.py   # 7 项静态检查
```

`tests\run_all.py` 的 19 组（顺序有理由，不要随意调）：

```
static  未定义名 / BOM / 未使用 import / 线程安全 / Settings 字段
theme   配色对比度与层次分离           cover   封面装饰不留大块补边
diag    卡死诊断（看门狗 / slow / 异常接管）
core    解析 / 缓存 / 对比 / 护栏 / 真实复制删除
adb     假 adb 驱动完整读写删          mtp     Shell CopyHere 镜像
gui     真实窗口驱动整条主流程          unit    解析器 / 数据库 / 设置 / 路径判定
songlist 列表控件     features 新功能     dialogs 对话框   i18n 多语言
wireless 无线调试      duplicates 重复检测  playlist 歌单     audio 试听（会开真声卡）
scaling 高 DPI 三档    shots   截图回归（**会弹窗置顶，故意排最后**）
```

**不在 `run_all` 里的两个**（需要真机，默认只演练）：

```powershell
python tests\e2e_device_real.py          # 真机读写删，**默认 dry-run**
python tests\e2e_device_real.py --yes    # 真跑（会自动复原歌单；有 Quest 型号护栏）
```

---

## 5. 文档同步要求（每次开发完必须做）

| 文档 | 什么时候改 |
|---|---|
| `CHANGELOG.md` | **每个版本都要**：日期、版本号、新增功能、BUG 修复、涉及文件、未解决问题 |
| `docs\04_迭代计划.md` | 任务状态变化时（改了某项的 ✅/🟡/⬜） |
| `docs\03_踩坑记录.md` | 踩到新坑就加一条（**连续编号，不许重复**） |
| `docs\00_AI接手指南.md` | 架构/命令/功能范围变化时 |
| `README.md` | 用户可见的功能或用法变化时 |
| `docs\` | 用户操作方式变化时 |
| 版本号 | `quest_tool\constants.py` 的 `APP_VERSION` |

---

## 6. 千万别做

* 别把 `shell_*.ps1` 存成无 BOM 的 UTF-8（PowerShell 5.1 会按 GBK 解码 → 中文路径乱码 → COM 调用失败）。
* 别在音频回调里调 `device.stop()`（会自锁死，实测挂死 2 分钟）。
* 别在工作线程碰任何 Tk 控件，包括 `root.after()`。
* 别用 `Set-Content -Encoding UTF8` 改 `.py` 文件（Windows PowerShell 5.1 会写入 BOM）。
* 别删 `docs\reference\`（原版代码留档，是"为什么这么改"的唯一证据）。
* 别在没跑 `run_all.py` 的情况下说"改好了"。
* 别只跑一个组就下结论 —— 本项目出现过多次「单独跑绿、混跑才红」的时序问题。

---

## 7. 遇到问题先看哪

| 症状 | 去哪 |
|---|---|
| 界面卡住 / 没反应 | `logs\quest_comparator.log`（菜单「帮助 → 环境自检信息」可直接看尾部） |
| 想知道以前踩过什么坑 | `docs\03_踩坑记录.md`（55 条，**先搜这里**） |
| 想知道为什么这么设计 | `HANDOVER.md` 第 9 节 + `docs\01_代码审查-原版问题清单.md` |
| 用户报"连不上 Quest / 选不了文件夹" | `docs\06_Quest3连接与文件夹选择.md` |
| 想知道还剩什么没做 | `docs\04_迭代计划.md` |
| 改界面 | `docs\02_UI设计说明.md` |
