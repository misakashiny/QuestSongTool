@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "PYW="
set "PY="

rem ---------- 1) find pythonw.exe (no console window) ----------
where pythonw.exe >nul 2>nul && set "PYW=pythonw.exe"
if not defined PYW if exist "%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe" set "PYW=%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe"

rem ---------- 2) find python.exe ----------
where python.exe >nul 2>nul && set "PY=python.exe"

if not defined PYW if not defined PY goto :no_python

rem ---------- 3) dependency check: install only if missing ----------
if defined PY (
    %PY% -c "import customtkinter, PIL" >nul 2>nul
    if errorlevel 1 (
        echo Installing UI dependencies ^(first run, needs internet, about 10 MB^)...
        %PY% -m pip install --disable-pip-version-check customtkinter pillow
        if errorlevel 1 goto :dep_failed
    )
    start "" "%PY%" "%~dp0main.py" %*
    goto :done
)

rem only pythonw was found (no console): cannot run pip from here
%PYW% -c "import customtkinter, PIL" >nul 2>nul
if errorlevel 1 goto :dep_no_console
start "" "%PYW%" "%~dp0main.py" %*
goto :done

:no_python
echo.
echo ============================================================
echo  Launch failed
echo ============================================================
echo  Python was not found on this computer.
echo  Install Python 3.10+ and tick "Add Python to PATH":
echo      https://www.python.org/downloads/
echo.
echo  Then run this launcher again.
echo.
pause
endlocal
exit /b 1

:dep_failed
echo.
echo ============================================================
echo  Launch failed
echo ============================================================
echo  Could not install the UI dependencies.
echo  Check your network, or run this by hand:
echo      pip install customtkinter pillow
echo.
pause
endlocal
exit /b 1

:dep_no_console
echo.
echo ============================================================
echo  Launch failed
echo ============================================================
echo  UI dependencies are missing, and only pythonw.exe was found
echo  (no console), so they cannot be installed automatically.
echo  Run this in a terminal first:
echo      pip install customtkinter pillow
echo.
pause
endlocal
exit /b 1

:done
endlocal
exit /b 0
